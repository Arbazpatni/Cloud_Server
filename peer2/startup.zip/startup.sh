#!/bin/bash
#peer2

# 1 - Maintanence, 0 - Normal [mode]
state=1

dotgcloud='https://github.com/Arbazpatni/Cloud_Server_2/blob/main/dot.gcloud.zip?raw=true'
dotgcloud2='12u7cr1UsrJBtN5PURV2c_1_29ZCI5T9u'
p2pemail='sowmiyancloud@gmail.com'
traffmonetizertoken='aXsmkQKOpuykMec+Y8vud7bl9APVsF5J5u0n5yIt29g='
account2='https://github.com/Arbazpatni/Cloud_Server/blob/main/peer2/account2.zip?raw=true'
account2_2='1iUhFjE4vJy7_Yj8pmYYEpjerzBBBO8Ah'
#setup=''
#setup2=''

GetDotGcloud()
{
    #wget --no-check-certificate ${dotgcloud} -O dot.gcloud.zip
    #unzip -o -q dot.gcloud.zip
    #rm dot.gcloud.zip
    GetDotGcloud1()
    {
        x=$1
        wget --no-check-certificate --content-disposition ${x}
    }
    GetDotGcloud2()
    {
        ggID=$1
        ggURL='https://drive.google.com/uc?export=download'
        filename="$(curl -sc /tmp/gcokie "${ggURL}&id=${ggID}" | grep -o '="uc-name.*</span>' | sed 's/.*">//;s/<.a> .*//')"
        getcode="$(awk '/_warning_/ {print $NF}' /tmp/gcokie)"
        curl -LOJb /tmp/gcokie "${ggURL}&confirm=${getcode}&id=${ggID}"
    }

    GetDotGcloud1 $dotgcloud

    if unzip -t "dot.gcloud.zip" >/dev/null 2>&1
    then
        echo "GITHUB mirror works!"
        unzip -o -q dot.gcloud.zip
        rm dot.gcloud.zip
    else
        echo "GITHUB mirror FAILURE!!!!!"
        GetDotGcloud2 $dotgcloud2

        if unzip -t "dot.gcloud.zip" >/dev/null 2>&1
        then
            echo "GDRIVE mirror works!!!"
            unzip -o -q dot.gcloud.zip
            rm dot.gcloud.zip
        else
        	rm dot.gcloud.zip
            echo "WARNING"
            echo "WARNING"
            echo "WARNING"
            echo "WARNING"
            echo "Both the mirrors failed!"
        fi
    fi

}

GetAccount()
{
    #wget --no-check-certificate ${account1} -O account1.zip
    #unzip -o -q account1.zip
    #rm account1.zip

    GetAccount1()
    {
        x=$1
        wget --no-check-certificate --content-disposition ${x}
    }

    GetAccount2()
    {
        ggID=$1
        ggURL='https://drive.google.com/uc?export=download'
        filename="$(curl -sc /tmp/gcokie "${ggURL}&id=${ggID}" | grep -o '="uc-name.*</span>' | sed 's/.*">//;s/<.a> .*//')"
        getcode="$(awk '/_warning_/ {print $NF}' /tmp/gcokie)"
        curl -LOJb /tmp/gcokie "${ggURL}&confirm=${getcode}&id=${ggID}"
    }

    GetAccount1 $account2
    
    if unzip -t "account2.zip" >/dev/null 2>&1
    then
        echo "GITHUB mirror works!"
        unzip -o -q account2.zip
        rm account2.zip
    else
        echo "GITHUB mirror FAILURE!!!!!"
        GetAccount2 $account2_2

        if unzip -t "account2.zip" >/dev/null 2>&1
        then
            echo "GDRIVE mirror works!!!"
            unzip -o -q account2.zip
            rm account2.zip
        else
        	rm account2.zip
            echo "WARNING"
            echo "WARNING"
            echo "WARNING"
            echo "WARNING"
            echo "Both the mirrors failed!"
        fi
    fi

}

export CLOUDSDK_CONFIG=$HOME/.gcloud
#check if init folder is present

if [ ! -e "init" ]
then
    echo "Init file is not present running installation script now"
    gcloud config configurations create peer2profit
    rm -r .gcloud
    echo "Pulling new .gcloud"
    GetDotGcloud
    touch init
elif [ $state -eq 1 ]
then
    echo "Updating .gcloud"
    #rm -r .gcloud
    echo "Pulling new .gcloud"
    GetDotGcloud
else
    echo "Normal Mode"
fi

echo "welcome to peer2profit! current time is $(date)"
docker_op=$(docker ps)
len=${#docker_op}
export P2P_EMAIL=${p2pemail};
echo "Output of docker ps"
echo $docker_op
echo "The length of the above output is"
echo $len
echo "Analysing the output"
if [ $len -lt 71 ]
then
    echo "Peer2profit peer seems to be down..."
    echo "Restarting the service :) !!"
    docker rm -f peer2profit || true && docker run -d --restart always         -e P2P_EMAIL=$P2P_EMAIL         --name peer2profit         peer2profit/peer2profit_linux:latest
    echo "Restarting traffmonetizer cli"
    docker run -d --name tm traffmonetizer/cli start accept --token ${traffmonetizertoken}
    echo "Done!"
else
    echo "Every thing seems to be good :)"
fi

docker_op=$(docker ps)
len=${#docker_op}
echo $docker_op
echo "Length of the docker ps command"
echo $len

if [ ! -e "account2" ]
then
    echo "Account file is not present"
    echo "Downloading account2"
    GetAccount
    echo "account2 downloaded"
elif [ $state -eq 1 ]
then
    echo "Updating account2"
    echo "Pulling new account2"
    #rm account2
    GetAccount
    echo "Done updating account2"
else
    echo "Normal Mode"
fi

daccount=account2
#dummy account stores the input file
fcount=$(grep -c ^ ${daccount})
fcount=$(($fcount+0))
paccount=$(whoami)
count=$(grep -wn "${paccount}" ${daccount} | cut -d: -f1)
while [[ -z ${account} ]]
do
    if [[ ! -z ${account} ]]
    then
        break
    else
        echo "moving to next line"
    fi
    count=`expr $count + 1`
    account=$(sed "${count}q;d" ${daccount})
    if [ "$count" -ge "$fcount" ]
    then
        echo "Reached the end of file"
        break
    fi
done

if [[ -z "$account" ]]
then
    echo "accounts exhausted"
else
    #See if start = 1
    if [ $state -eq 1 ]
    then
        echo "Updating setup script"
        echo "Pulling new setup script"
        #gcloud cloud-shell ssh -q --authorize-session --command="rm setup.sh" --account ${account}
        #c=$'' -> we can use double quotes inside here but we need to escape single quotes like \'
        c=$'setup="https://github.com/Arbazpatni/Cloud_Server/blob/main/peer2/setup.zip?raw=true"; setup2="14Kopzi547zw_bBMFnlPYM4vil2HhDEzv"; GetSetup1() { x=$1; wget --no-check-certificate --content-disposition ${x}; }; GetSetup2() { ggID=$1; ggURL=\'https://drive.google.com/uc?export=download\'; (filename="$(curl -sc /tmp/gcokie "${ggURL}&id=${ggID}" | grep -o \'="uc-name.*</span>\' | sed \'s/.*">//;s/<.a> .*//\')"); (getcode="$(awk \'/_warning_/ {print $NF}\' /tmp/gcokie)"); (curl -LOJb /tmp/gcokie "${ggURL}&confirm=${getcode}&id=${ggID}"); }; GetSetup1 $setup; if unzip -t "setup.zip" >/dev/null 2>&1 ; then echo "GITHUB mirror works!"; unzip -o -q setup.zip; rm setup.zip; else echo "GITHUB mirror FAILURE!"; GetSetup2 $setup2; if unzip -t "setup.zip" >/dev/null 2>&1; then echo "GDRIVE mirror works!"; unzip -o -q setup.zip; rm setup.zip; else echo "WARNING"; echo "WARNING"; rm setup.zip; echo "WARNING"; echo "WARNING"; echo "Both the mirrors failed!"; fi; fi; chmod +x ./setup.sh; ./setup.sh;'
        #"${c}" 
        gcloud cloud-shell ssh -q --authorize-session --command="${c}" --account ${account}
    else
        #otherwise don't download setup script just run the already downloaded script.
        gcloud cloud-shell ssh -q --authorize-session --command=$'sed -i \'5s/.*/state=0/\' setup.sh' --account ${account}
        echo "Normal Mode"
        gcloud cloud-shell ssh -q --authorize-session --command="./setup.sh" --account ${account}
    fi
    while [ true ]
    do
        export CLOUDSDK_CONFIG=$HOME/.gcloud
        echo $paccount
        echo "Is starting ..."
        echo $account
        gcloud cloud-shell ssh -q --authorize-session --command="bash .bashrc;bash -l" --account ${account}
        echo "An error occured"
    done
fi
