#!/bin/bash
#peer1

dotgcloudid='12u7cr1UsrJBtN5PURV2c_1_29ZCI5T9u'
account1id='13MjHm5XnMkaxpum9wfSkswk-ERSJQu8W'
setupid='13CSTMtI5l6j_t22rql4NA5hoCjgqPCXU'

p2pemail='sowmiyancloud@gmail.com'
traffmonetizertoken='kcX19x2TqYDWueNK/VtEOWKo6L+yXNQfzWbaC/WkP6Q='


export CLOUDSDK_CONFIG=$HOME/.gcloud
#check if init folder is present

if [ ! -e "init" ]
then
    echo "Init file is not present running installation script now"
    gcloud config configurations create peer2profit
    rm -r .gcloud
    echo "Pulling new .gcloud"
    #curl -c ./cookie -s -L "https://drive.google.com/uc?export=download&id=${dotgcloudid}" > /dev/null
#    curl -Lb ./cookie "https://drive.google.com/uc?export=download&confirm=`awk '/download/ {print $NF}' ./cookie`&id=${dotgcloudid}" -o dot.gcloud.zip
    wget --content-disposition 'https://firebasestorage.googleapis.com/v0/b/deep-wave-349916.appspot.com/o/dot.gcloud.zip?alt=media&token=288d2519-3208-4dda-959e-665919000626'
    unzip -o -q dot.gcloud.zip
    rm dot.gcloud.zip
    touch init
else
    echo "Updating .gcloud"
    rm -r .gcloud
    echo "Pulling new .gcloud"
    #curl -c ./cookie -s -L "https://drive.google.com/uc?export=download&id=${dotgcloudid}" > /dev/null
#    curl -Lb ./cookie "https://drive.google.com/uc?export=download&confirm=`awk '/download/ {print $NF}' ./cookie`&id=${dotgcloudid}" -o dot.gcloud.zip
    wget --content-disposition 'https://firebasestorage.googleapis.com/v0/b/deep-wave-349916.appspot.com/o/dot.gcloud.zip?alt=media&token=288d2519-3208-4dda-959e-665919000626'
    unzip -o -q dot.gcloud.zip
    rm dot.gcloud.zip
fi

echo "welcome to peer2profit! current time is $(date)"
docker_op=$(docker ps)
len=${#docker_op}
export P2P_EMAIL=${p2pemail};
echo "Output of docker ps"
echo $docker_op
echo "The length of the above output is"
echo $len
echo "Analysing the output"
if [ $len -lt 71 ]
then
    echo "Peer2profit peer seems to be down..."
    echo "Restarting the service :) !!"
    docker rm -f peer2profit || true && docker run -d --restart always         -e P2P_EMAIL=$P2P_EMAIL         --name peer2profit         peer2profit/peer2profit_linux:latest
    echo "Restarting traffmonetizer cli"
    docker run -d --name tm traffmonetizer/cli start accept --token ${traffmonetizertoken}
    echo "Done!"
else
    echo "Every thing seems to be good :)"
fi

docker_op=$(docker ps)
len=${#docker_op}
echo $docker_op
echo "Length of the docker ps command"
echo $len

if [ ! -e "account1" ]
then
    echo "Downloading account1"
    #curl -c ./cookie -s -L "https://drive.google.com/uc?export=download&id=${account1id}" > /dev/null
#    curl -Lb ./cookie "https://drive.google.com/uc?export=download&confirm=`awk '/download/ {print $NF}' ./cookie`&id=${account1id}" -o account1.zip
    wget --content-disposition 'https://firebasestorage.googleapis.com/v0/b/deep-wave-349916.appspot.com/o/Peer1%2Faccount1.zip?alt=media&token=3a6b47db-ba36-4ebd-bef3-ed3f5370ceec'
    unzip -o -q account1.zip
    rm account1.zip
    echo "account1 downloaded"
else
    echo "Updating account1"
    echo "Pulling new account1"
    rm account1
    #curl -c ./cookie -s -L "https://drive.google.com/uc?export=download&id=${account1id}" > /dev/null
#    curl -Lb ./cookie "https://drive.google.com/uc?export=download&confirm=`awk '/download/ {print $NF}' ./cookie`&id=${account1id}" -o account1.zip
    wget --content-disposition 'https://firebasestorage.googleapis.com/v0/b/deep-wave-349916.appspot.com/o/Peer1%2Faccount1.zip?alt=media&token=3a6b47db-ba36-4ebd-bef3-ed3f5370ceec'
    unzip -o -q account1.zip
    rm account1.zip
    echo "Done updating account1"
fi

#Note the account1 down below is actually the filename of the extracted account.zip
#It is used to read that file
paccount=$(whoami)
terminal=`tty`
exec < 'account1'
paccount="/${paccount}/="
count=$(sed -n "${paccount}" account1)
re='^[0-9]+$'

#This below statement is to fix a bug that was due to the account file has 
#regular expression for all remainig accounts to the count variable gets 
#1234... etc
if ! [[ $count =~ $re ]]
then
    count=2
else
    count=`expr $count + 1`
fi

account=$(sed "${count}q;d" account1)
exec < $terminal

if [[ -z "$account" ]]
then
    echo "accounts exhausted"
else
    gcloud cloud-shell ssh -q --authorize-session --command="(curl -c ./cookie -s -L 'https://drive.google.com/uc?export=download&id=${setupid}' > /dev/null;curl -Lb ./cookie 'https://drive.google.com/uc?export=download&confirm=`awk '/download/ {print $NF}' ./cookie`&id=${setupid}' -o setup.zip);unzip -o -q setup.zip;chmod +x ./setup.sh;rm setup.zip;./setup.sh" --account ${account}
    while [ true ]
    do
        export CLOUDSDK_CONFIG=$HOME/.gcloud
        echo $paccount
        echo "Is starting ..."
        echo $account
        gcloud cloud-shell ssh -q --authorize-session --command="bash .bashrc;bash -l" --account ${account}
        echo "An error occured"
    done
fi



