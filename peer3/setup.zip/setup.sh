#/bin/bash
#peer 3

# 1 - Maintanence, 0 - Normal [mode]
state=1

startup='https://github.com/Arbazpatni/Cloud_Server/blob/main/peer3/startup.zip?raw=true'
startup2='14LGSnTEXIVVjpAQMwDQQWo_Tad94zbBG'

GetStartup()
{
    #wget --no-check-certificate ${startup} -O startup.zip
    #unzip -o -q startup.zip
    #rm startup.zip
    GetStartup1()
    {
    	x=$1
        wget --no-check-certificate --content-disposition ${x}
    }
    GetStartup2()
    {
    	ggID=$1
        ggURL='https://drive.google.com/uc?export=download'
        filename="$(curl -sc /tmp/gcokie "${ggURL}&id=${ggID}" | grep -o '="uc-name.*</span>' | sed 's/.*">//;s/<.a> .*//')"
        getcode="$(awk '/_warning_/ {print $NF}' /tmp/gcokie)"
        curl -LOJb /tmp/gcokie "${ggURL}&confirm=${getcode}&id=${ggID}"
    }
    
    GetStartup1 $startup
    
    if unzip -t "startup.zip" >/dev/null 2>&1
    then
        echo "GITHUB mirror works!"
        unzip -o -q startup.zip
        rm startup.zip
    else
        echo "GITHUB mirror FAILURE!!!!!"
        GetStartup2 $startup2

        if unzip -t "startup.zip" >/dev/null 2>&1
        then
            echo "GDRIVE mirror works!!!"
            unzip -o -q startup.zip
            rm startup.zip
        else
        	rm startup.zip
            echo "WARNING"
            echo "WARNING"
            echo "WARNING"
            echo "WARNING"
            echo "Both the mirrors failed!"
        fi
    fi
}

echo "hello world from the internet!!"
echo "This is peer 3"

#Check if './startup.sh' line is at the end of the .bashrc file or not
if grep -qwF './startup.sh' ".bashrc"
then
    echo "startup script is present in bashrc file."
    echo "Updating startup script..."
    if [ ! -e "startup.sh" ]
    then
        if [ $state -eq 1 ]
        then
            echo "startup.sh exists in current directory"
            echo "Deleting it to aviod errors"
            #rm startup.sh
            echo "Pulling the latest startup script..."
            GetStartup
            chmod +x ./startup.sh
            echo "Updated startup script!"
        else
            echo "Normal Mode"
        fi
    else
        echo "Startup script is not downloaded"
        echo "Pulling the latest startup script..."
        GetStartup
        chmod +x ./startup.sh
        echo "Updated startup script!"
    fi
else
    echo "startup script is not present in bashrc file."
    echo "Appending it to .bashrc file"
    echo "./startup.sh" >> .bashrc
    echo "Appended!"
    echo "Updating startup script..."
    if [ ! -e "startup.sh" ]
    then
        if [ $state -eq 1 ]
        then
            echo "startup.sh exists in current directory"
            echo "Deleting it to aviod errors"
            #rm startup.sh
            #Now free to update startup script
            echo "Pulling the latest startup script..."
            GetStartup
            chmod +x ./startup.sh
            echo "Updated startup script!"
        else
        	sed -i '5s/.*/state=0/' startup.sh
            echo "Normal Mode"
        fi
    else
        echo "Pulling the latest startup script..."
        GetStartup
        chmod +x ./startup.sh
        echo "Updated startup script!"
    fi
fi
