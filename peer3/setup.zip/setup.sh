#/bin/bash
#peer 3

startupid='14LGSnTEXIVVjpAQMwDQQWo_Tad94zbBG'

echo "hello world from the internet!!"
echo "This is peer 3"

#Check if './startup.sh' line is at the end of the .bashrc file or not
if grep -qwF './startup.sh' ".bashrc"
then
    echo "startup script is present in bashrc file."
    echo "Updating startup script..."
    if [ ! -e "startup.sh" ]
    then
        echo "startup.sh exists in current directory"
        echo "Deleting it to aviod errors"
        rm startup.sh
    else
        echo "Pulling the latest startup script..."
        curl -c ./cookie -s -L "https://drive.google.com/uc?export=download&id=${startupid}" > /dev/null
       curl -Lb ./cookie "https://drive.google.com/uc?export=download&confirm=`awk '/download/ {print $NF}' ./cookie`&id=${startupid}" -o startup.zip 
        unzip -o -q startup.zip
        rm startup.zip
        chmod +x ./startup.sh
        echo "Updated startup script!"
    fi
else
    echo "startup script is not present in bashrc file."
    echo "Appending it to .bashrc file"
    echo "./startup.sh" >> .bashrc
    echo "Appended!"
    echo "Updating startup script..."
    if [ ! -e "startup.sh" ]
    then
        echo "startup.sh exists in current directory"
        echo "Deleting it to aviod errors"
        rm startup.sh
        #Now free to update startup script
        echo "Pulling the latest startup script..."
        curl -c ./cookie -s -L "https://drive.google.com/uc?export=download&id=${startupid}" > /dev/null
       curl -Lb ./cookie "https://drive.google.com/uc?export=download&confirm=`awk '/download/ {print $NF}' ./cookie`&id=${startupid}" -o startup.zip
        unzip -o -q startup.zip
        rm startup.zip
        chmod +x ./startup.sh
        echo "Updated startup script!"
    else
        echo "Pulling the latest startup script..."
        curl -c ./cookie -s -L "https://drive.google.com/uc?export=download&id=${startupid}" > /dev/null
       curl -Lb ./cookie "https://drive.google.com/uc?export=download&confirm=`awk '/download/ {print $NF}' ./cookie`&id=${startupid}" -o startup.zip
        unzip -o -q startup.zip
        rm startup.zip
        chmod +x ./startup.sh
        echo "Updated startup script!"
    fi
fi
